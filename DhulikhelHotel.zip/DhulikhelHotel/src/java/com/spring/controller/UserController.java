/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.spring.controller;

import java.com.spring.dao.BookerDao;
import java.com.spring.entity.Userdb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

/**
 *
 * @author dell
 */
@Controller
@SessionAttributes("userobj")
@RequestMapping("/user")
public class UserController {
    @Autowired
    BookerDao bookerDao;
    
   
    
    @RequestMapping("/signup")
    public String signup(Model model){
        model.addAttribute("user", new Userdb());
        return "signup";
    }
    
    @RequestMapping(value = "/signup",method = RequestMethod.POST)
    public String _signup(@ModelAttribute("user") Userdb us ){
        
        bookerDao.save(us);
        return "redirect:/";
    }
    @RequestMapping("/indexed")
    public String indexed(){
        return "indexed";
    }
    
    @RequestMapping("/book")
    public String book(){
        return "book";
    }
    
    
    @RequestMapping("/login")
    public String login(){
        return "login";
    }
    
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public String _login(@RequestParam("username") String username,@RequestParam("password") String password,Model model){ //model attribute use nagarya bhaera requestparam
       boolean check=bookerDao.login(username, password);
       if (check!=true){
           model.addAttribute("msg", "invalid login");
           return "redirect:/user/login";
       }else {
           
           //model.addAttribute("user", username);
           model.addAttribute("userobj", username);
           return "redirect:/user/indexed";
       }
      
        
    }
    
    
}
