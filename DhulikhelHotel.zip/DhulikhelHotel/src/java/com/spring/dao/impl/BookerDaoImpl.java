/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.spring.dao.impl;

import java.com.spring.dao.BookerDao;
import java.com.spring.entity.Userdb;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.hibernate.SessionFactory;
//import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author dell
 */
@Repository("bookerDao")//name same as object created in controoler in this case Usercontroller
public class BookerDaoImpl implements BookerDao{

    @Autowired
    SessionFactory sessionfactory;
    
    

    
        
  

    @Transactional //@Override thyo tara commit garnu parne bhaeko le transactional 
    public boolean login(String username, String password) {
        boolean  check=false;
        Userdb us=null;//check garna edi null chaina bhne boolean true banauna sajilo huncha bhnera
        try {
         
             us=(Userdb)sessionfactory.getCurrentSession().createQuery("from Userdb where username=:x and password=:y")
                    .setParameter("x", username)
                    .setParameter("y", password)
                    .uniqueResult();
        } catch (Exception e) {
            System.out.println(""+e);
        }
        if(us!=null){
            check=true;
            
        }
        
        return check;
    }

   @Transactional
    public void save(Userdb us) {
        try {
            sessionfactory.getCurrentSession().saveOrUpdate(us);
            ///email pathauna ko lagi 
           // String from=us.getEmail();//db ma email rakhya chaina 
            
            Email email = new SimpleEmail();
            email.setHostName("smtp.googlemail.com");
            email.setSmtpPort(465);
            //email.setAuthenticator(new DefaultAuthenticator("username", "password"));
            email.setAuthentication("dhulikhelboutique@gmail.com", "boutique2017");
            email.setSSLOnConnect(true);
            email.setFrom("dhulikhelboutique@gmail.com");
            email.setSubject("Booking");
            email.setMsg(us.getFirstname()+" " +"has booked room from online. /n Please check and confirrm the booking+"
                    + "/n Phone: "+us.getPhone()
                    +"/n Email:"+us.getEmail());
            email.addTo("sansiven@yahoo.oom");
            email.send();
        } catch (EmailException ex) {
            Logger.getLogger(BookerDaoImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
